import React from 'react'

const Navigation = () => {
  return (
    <div className='navigation'></div>
  )
}

export default Navigation