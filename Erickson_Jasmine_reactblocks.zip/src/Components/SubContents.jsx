import React from 'react'

const SubContents = () => {
  return (
    <div className='subContents'></div>
  )
}

export default SubContents