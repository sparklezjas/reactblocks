import React from 'react'

const Main = () => {
  return (
    <div className='main'>
        <div className='subContents'></div>
        <div className='subContents'></div>
        <div className='subContents'></div>
        <div className='advertisement'></div>
    </div>
  )
}

export default Main